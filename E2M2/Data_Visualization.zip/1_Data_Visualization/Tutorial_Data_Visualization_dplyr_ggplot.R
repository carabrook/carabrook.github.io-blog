#############################################################################
##   Exploring and visualizing data in R
#############################################################################
##   Ecological and Epidemiological Modeling in Madagascar (E2M2)
##   27h of November to 3rd of December 2016
##   ValBio center, Ranomafana, Fianarantsoa, Madaascar
#############################################################################
##   Hafaliana Christian Ranaivoson, 2016
##   Zoology and animal Biodiversity, Univesity of Antananarivo
#############################################################################
##   The goal of this tutorial is to introduce students to data 
##   management and data visualisation using the R statistical software
##   To reach this goal, the tutorial will use a fake dataset created under
##   R software.
##   The data sets was created from real observed parameters from bat capture
##   It also borrow general charateristics of some hemoparasite infection pattern
##   Though fake, the data point out some aspect of some hemoprasite infection 
##   to help cope how R software can be used to manage raw data and visualize
##   some pattern of biologicalevents.
#############################################################################
##   Data story: 
##   Small fruit bats "fb" were captured from one locality. 100 bats were net
##   captured every month of the year, for one year.
##   For each captured individual, a unique Id was given "fb". The length of
##   the forearm (in mm) was measured and the each bat was weighted (in gramm)
##   , sexed and aged.
##   Prevalence (Prev) of hemoparasite was obtained by observation under microscopy
##   and recorded as 0 when absent and 1 when present. Parasitemia (para) was
##   recorded as the number of  microscopy positive field out of 200 field observation
##   under high magnification. All data was recorded on excel software as 
##   csv file, "e2m2_FB.csv".
#############################################################################
##   Before starting the software, make sure you already create a folder in 
##   your computer so you can find and access it easily.Copy all files you need
##   for this tutorial: "tuto_e2m2.R" and "e2m2_FB.csv".
##   Note that the symbol "#" is used to put note within your code. Anything 
##   placed after this symbol in a row will not be execute as code.
#############################################################################
############            Set Working Directory      ########################
##  get the default directory use by R

getwd()

##  set your own directory
##  note that both the two line work the same way \\ or / the path of your file
##  do not forget te quote "".

setwd("D:\\STUDY\\PhD\\OneDrive\\ActivData\\Reports\\E2M2")

setwd("D:/STUDY/PhD/OneDrive/ActivData/Reports/E2M2")

##  Now change the file path to meet your file path and execute the code.

######################################################################
############             Impoting data              ##################
######################################################################
##  Import the dataset named "e2m2_FB.csv" to a new data name.

e2m2 <- read.csv("e2m2_FB.csv",stringsAsFactors = F,header = T)

## In the code above, we tell R to not change strings to a factor by setting stringsAsFactor
## to False "F". If we did not set this, R will change all strings entry to factor,and...
## We do not need that
## Your data should be listed in the R data enviroment list under R studio.
## Now, check your imported data by the View() function. You can use this fucntion
## to view any data in the R data environment. Another way is just type the data name
## directly, but it will be shown in the R consol an won't as nice as the View() function

View(e2m2)

## Try
e2m2

#################################################################
################        Exploring data      #####################
#################################################################
## Use the dim() and names() function to get an overview of you data

dim(e2m2)

names(e2m2)

## How many columns and rows are there in the data?
## What variables are we interested in?
## Refer to the data story to have more information.

## Now that you know our variable names, try to print out the content of some of them
## Use the combination of dataset name and variable name by $ symbol to do so.

e2m2$Forearm

## Now filter the content with [...] to show specific data, for example th Id of fruit bats
## which have a forearm length smaller than 56 mm.

e2m2$Id[e2m2$Forearm < 56]

## You are told to print out bat Id that have forearm smaller than 40 mm
## Try it
## What happened?

## You can get the count of bat which have a forearm smaller than 56 mm by using
## length(...) function. Which give 130 bats.

length(e2m2$Id[e2m2$Forearm < 56])

## You are asked to tell how many bats have a forearm longer than 70 mm
## how many?
## You can add more logic filter within [...] by using "and" or/and "or" logical conjunction.
## "and" is represented by the "&" symbol. It means both filter is true
## "or" is represented by the "|" symbol. It means one or the other is true
## For example, the next code print out the count of bats which have a forearm longer than
## 70 mm and smaller than 75 mm. which is 238 bats

length(e2m2$Id[e2m2$Forearm > 70 & e2m2$Forearm < 75])

## Now try to get the number of bats that have a forearm length within 60 to 70 mm.

########################     Data structure     ########################
## You are now able to access any data within the dataset. It is time to see what type
## of variable do we have. This is important since the operation we can use on them
## will also depend on their type.

## The function str(...) which means structure can be used to do so.

str(e2m2)

## What can you tell after executing the code above?
## The way we record data on the field may depends on the goal we want to acheive and
## the way we get them. Some people may record age data as age group and use character
## instead of numbers. But we should keep the same structure for the same variable.
## But sometimes, after entering a thousands records, we may do some typing error or
## we just mixed type of entry.
## Try to identify error in the result from the str(...) function we have applied to 
## our data.
##
## When we told R to just read our data as is (see import data above) it just imported
## the data as numeric or as character. Though numeric can be represented with integer
## (int) for non decimal numbers or numeric if decimal numbers.
##
## Most of the case str(..) function will not suffice to figure out erros in the data, just
## because R is only showing the first five rows. You need to set the variables to the
## needed format first and search for errors.
## 
## You will decide what type you want R to treat your variable. The R software work mainly
## on the following type of variables.
##
## - Factor: is a grouped identity. R group all same values in your variable as categories
##   ex: Sex will be grouped as male or female. as.factor(...) is the funtcion 
##   to factor variables. Levels are the categories.
##
## - Numeric: is numeric variable. as.numeric(...) is the function.
##
## - Date: is time variable. as.Date(...) is the function. For this one, you need to tell R
##   how you recorded your date. It means the format.
##   The default format R is reading Date is "%Y-%m-%d" which mean Year-month-day (ex: "1900-12-30")
##   If the way you record your date is not the same, you need to point it to R.
##   Here, our date is recorded as "%m/%d/%Y", month/day/Year.
##
##   Then we write: as.Date(e2m2$Date,format="%m/%d/%Y)

## - NA: Not Available. They are missing values. There are function to handle Na values.
##
## Let's set our Variable types:
## Do not assign variable, we do not want R to save them in Rdata yet, just try
## We are trying to factor the Sex Variable:

as.factor(e2m2$Sex)

## What do we get?
## R printed out the values and at the bottom the levels. Levels are the number of category in the
## Variable. How many we got? Does it seem right?
## Of course not, Sex should have only two categories, Male or Female. What was wrong?
## You can see, we typed f in three different ways. f F f. Male "m" seems to be OK.
## R is case sensitive, you need to type exactly the same way.
##
## Let's move to another variables:
## We will deal with Age variable. We have already seen something was wrong with it from the str()
## We are going to set age variable as numeric.

as.numeric(e2m2$Age)

## R printed out values, and at the bottom, a warining message. It says NA value are introduced.
## It means that R does not know how to change some values to numeric.

## Let's move to another variable, the Date variable:

as.Date(e2m2$Date,format="%m/%d/%Y")

## R ptinted out the values without any warning. We are fine with the date variable then.
## Note that R is showing the Date by it's default format "%Y-%m-%d", this is a good sign.

## Now, we know which variable has error, it is time to correct them. Let's move to..

###################           Correcting Data    #######################

########            Finding the wrong values     #############################"
## Now, we know that Age and Sex variables have values errors. We need to find them.
## A simple way is to go back to the excel data. The problem is that excel is not realy case sensitive
## If you filter the variable Sex in excel, all three f F f will be the same letter.
## We can use R to search for them. Let use structure function to a factored Sex variable.

str(as.factor(e2m2$Sex)) 
## Yes you can even use combination of function in R! Here we combine str() and as.factor()

## R printed out 4 levels and the levels values. What do you see? : "f", "F", "f "
## What different with the three f? The one is Uppercase and the other one has space after it.
## Look closely at the quote "". We found them!

## Let's move to the Age variables.
## We need to find which values are not numerical. Previously, we saw that R return some NA value
## when we tried to set Age as numeric. Then we need to find which produce NA values.

e2m2$Age[is.na(as.numeric(e2m2$Age))]

## Here we accessed the Age variable. Then we filter the content by [...] (do you remember?).
## inside the filter, we want content that produce NA values (with is.na(...)) when we set Age
## variable ## as numeric.
## R will print out the values we were searching for. What are those values?
## R will surely produce warning message at the bottom but we only need the values.
## As you can see, some age data were recorded as character: "seven", "nine", "one"
## 
## We can use the same logic to find the wrong value for Sex.
## We know that levels should only be male or female, and the right way to type them is "f" and "m".
## All, lowercase and no space.
## Try the following code. (!= means not equal to)

e2m2$Sex[e2m2$Sex != "f" & e2m2$Sex !="m"]

## We have found all wrong values, it is time to correct them
##
## ###############         Changing Values         #####################
## Keep in mind that we have not assigned any data type to our variables yet.
## They are still character or numeric

str(e2m2)

## Changing values of a variable is a straight forward manipulation. It is just all about assigning
## the new value to the previous one.
## So, let's assign the right value "f" (lower case, no space) to the wrong value "F" and "f ".

e2m2$Sex[e2m2$Sex=="F"] <- "f"

e2m2$Sex[e2m2$Sex=="f "] <- "f"

## Now try to factor the Sex variable again

as.factor(e2m2$Sex)

## How many levels do we have now?         Which are they?         Are we good now?
## Now try to do the same thing to correct value of Age variable, and try as.numeric(...) again.

e2m2$Age[e2m2$Age=="seven"] <- "7"

e2m2$Age[e2m2$Age=="nine"] <- "9"

e2m2$Age[e2m2$Age=="one"] <- "1"

as.numeric(e2m2$Age)

## Is there any warning message again?
## Now, everithing is ok, we can assign the right format to our variables finally

e2m2$Sex <- as.factor(e2m2$Sex)

e2m2$Prev <- as.factor(e2m2$Prev)

e2m2$Age <- as.numeric(e2m2$Age)

e2m2$Date <- as.Date(e2m2$Date, format="%m/%d/%Y")

## Now try the str(...) function on our data again.

str(e2m2)

## We are good!

## What we have done so far is to correct already existing variables
## We can also use what we have learned to create new variables!
## It is just about assigning values to new variable name!...What?!
##
## In the example below, we are creating a new categorical variable named "Size"
## with three levels (small, medium, and large) from the Forearm variable.

e2m2$Size[e2m2$Forearm < 60] <- "small"

e2m2$Size[e2m2$Forearm >= 60 & e2m2$Forearm < 75] <- "Medium"

e2m2$Size[e2m2$Forearm >= 75] <- "Large"

e2m2$Size <- as.factor(e2m2$Size)

View(e2m2)

## Now create a new variable named AgeClass from the Age variable, and factor it.
## for this, we need six categories as follow:
##     - 1 younger than 2.5 year
##     - 2 between 2.5 to 5 year
##     - 3 between 5 to 7.5 year
##     - 4 between 7.5 to 9 year
##     - 5 between 9 to 12 year
##     - 6 older than 12 year

## We done here!
## It is time to play with the data now
############################################################################################
#################################         Visualizing Data        ##########################
############################################################################################

#####################     Arrange data   #####################
## For this we will need the package "dplyr"
## If you do have this packages yet, install it with the function "install.packages(...)"

install.packages("dplyr")
install.packages("ggplot2")

## Then load it with require() or library()

require(dplyr)
require(ggplot2)

## The package dplyr contains usefull fonctions for data management.
## We will see three funtion from it: filter(), group_by(), summarise()

#########  group_by(...) 
## This function will produce new dataset  grouped by the value of a variable.Then, operations on
## the data will be executed by group. It is very usefull when combined with the summarise() function.

#########  summarize(...)
## This function will produce a new dataset which return summary of the previous variables to new variables.
## These new variables are defined by the user.
## 
## Example: You want to summarize the mean of forearm by the sex of bats from our e2m2 dataset.

## First we group our data by Sex, and assign it to a new dataset name (this avoid to overwrite our data)
groupsex <- group_by(e2m2,Sex)

## Then we use the newly created data to get the mean of forearm, we assign it again to a new dataset
stat_groupsex <- summarise(groupsex,
                           mean = mean(Forearm,na.rm=T),
                           count = n())

## to undestand What we did, try to view the stat_groupsex dataset

View(stat_groupsex)

## As you can see the operation was made by group, The sex variable.
## We created a variable "mean" by using Forearm mean " -> mean = mean(Forearm,na.rm=T)
## na.rm=T tell to remove NA values from the operation mean().
## We also created an new variable "count" that summarize the number of data. count=n()

## Try to do the same thing. summarize the mean of Weight by the Sex of bats.
## And later, try to summarize mean Forearm by Sex and Size of bats.
##
## Note that group_by() only work for factor variable.


## filter(...) will chose a part of the data by row according to a filter you have set.

## For example, you may need to work only with female bats from our data. The you can write.

femalebats <- filter(e2m2, Sex=="f")

malebats <- filter(e2m2, Sex=="m")

## R will create a new dataset which will contain only female bats data. You can add more filtering
## variable.
## Try to filter female bats with medium size.

## These three function is very usefull when you want to arrange you data for a specific need.
## Now it is time to have a graphical Visualization of our data

#########################     Data Plotting    ############### ########
#######  ggplot2  #######
## ggplot 2 is a powerful graphic R package. ggplot is a complex graphical vocabularies but is
## in a simple an intuitive way.
## 
## The function ggplot2(...) produce the base plot with th xy axis. Then you just have to choose from
## a list of geometrics (geom) to populate the base plot.
## However you must know the type of variable you are mapping to xy axis. Indeed, each geom should be
## used with the apropriate type of variable.
##
## Let's start with female bats with age younger that 2 months.
## When you try this code, execute it one by one first to see the difference.

femyoung <- filter(femalebats,Age<2)

## Let's built our base plot with Weight in y axis and Forearm in x axis

ggplot(femyoung,aes(Forearm,Weight))  ##Try this


## ggplot created a blank plot with our xy axis as Foearm and Weight.
## We now need to tel R to populate the plot with the function geom_
## Here you have a list of geom in ggplot. It is up to you to choose which best fit for your data.
## We will start with point since we have two continuous variables.

ggplot(femyoung,aes(Forearm,Weight)) +
  geom_point()

## try Line

ggplot(femyoung,aes(Forearm,Weight)) +
  geom_line()

## put them in the same plot

ggplot(femyoung,aes(Forearm,Weight)) +
  geom_point() +
  geom_line()

## Add a smooth to the point plot
ggplot(femyoung,aes(Forearm,Weight)) +
  geom_point() +
  geom_smooth()


############  Mapping aesthetic vs Fixed Value   ##################
ggplot(e2m2,aes(Forearm,Weight)) +
  geom_point() +
  geom_line()

## The code above plot the lenght of bats Weight by the Forearm. You can clean the plot by grouping
## your variable and a clearer separation in the curve.
## ggplot offer you a list of aesthetic that can be used to polish your plot.
## 
## First, let's give a fixed value to our aesthetics

ggplot(e2m2,aes(Forearm,Weight)) +
  geom_point(color="red", shape=3)

## Not better
## You can map your variable to the aesthetic to give a clear separation.

ggplot(e2m2,aes(Forearm,Weight)) +
  geom_point(aes(color=Sex, Shape=Sex))

## Note that, When you want to map the aesthetic to a variable, you need to use the aes().
## All aesthetic outside that function will be considered as fixed.

##################       Polishing the plot       ###############
## You can access plot element and set a custom setting to give nice look to your plot
## There are a big list of theming in ggplot. But We will just see "ggtitle() and scale()
## 

ggplot(e2m2,aes(Forearm,Weight)) +
  geom_point(aes(color=Sex, Shape=Sex)) +
  
ggtitle("Weight by Forearm of Young Bats")+
  
  scale_x_continuous(name="Length forearm (mm)",
                     limits=c(20,100))+
  
  scale_y_continuous(name="Weight (g)",
                     limits=c(0,90))+
  
  scale_color_discrete(name="Sex",
                       breaks=c("f","m"),
                       label=c("female","male"))+
  
  scale_shape_discrete(name="Sex",
                       breaks=c("f","m"),
                       label=c("female","male"))


##############           Plotting Prevalence           ################
### Proportion of positif case in population.
###   Calculating Prevalence by sex

sexprev <- summarise(groupsex,
                     pre=length(Sex[Prev=="1"])/n())

ggplot(sexprev,aes(Sex,pre)) +
  geom_bar(stat='identity') +
  ggtitle("Sex Prevalence of Hemoparasites") +
  scale_y_continuous(name="Prevalence",limits=c(0,1)) +
  scale_x_discrete(breaks=c("f","m"), labels=c("female","male")) +
  theme_minimal(base_size=34)


## Calculatin Prevalence by month
## Date is a particular data type. But, to be simple it is just a relative location in a series
## of points. It can be then plot as a simle coordinate.

ggplot(e2m2,aes(Date,Weight)) + geom_line()

## Oooopssssssss! This kook messy
## When you have a lot of data at the same point or almost at the same point, it is often better
## to summarise them and create a group.
## The Date can be switch to factor, or numeric. Here we need it to be a factor.
## But first, we need to change the format to show month, we are grouping the data by month.
## To keep our original variable, we will create a new variable, monthly

e2m2$monthly <- format(e2m2$Date,"%m")
e2m2$monthly <- as.factor(e2m2$monthly)

## Here we introduced a new function, theme() which help in custo;izing the plot aspect.
## There some preset them in R, like this one, but you can also customize theme.

e2m2$monthly

## Use Box plot to see the distribution of our bat weight each month.

ggplot(e2m2,aes(monthly,Weight)) +
  geom_boxplot()

## Let's see it by sex

ggplot(e2m2,aes(monthly,Weight)) +
  geom_boxplot(aes(color=Sex))

####################    Let,s see monthly prevalence, using the same method as above.
## Monthly prevalence
##
monly <- group_by(e2m2,monthly)
monprev <- summarise(monly,
                     pre=length(Sex[Prev=="1"])/n())

ggplot(monprev,aes(monthly,pre)) +
  geom_bar(stat='identity') +
  ggtitle("Sex Prevalence of Hemoparasites") +
  scale_y_continuous(name="Prevalence",limits=c(0,1)) +
  scale_x_discrete(name="month",
                   breaks=c('01','02','03','04','05','06','07','08','09','10','11','12'),
                   labels= c(month.abb)) +
  
  theme_minimal(base_size=34)

##  Create a variable for Age Class if did not do it yet.
##
e2m2$AgeClass[e2m2$Age < 2.5] <- 1
e2m2$AgeClass[e2m2$Age >= 2.5 & e2m2$Age <5] <- 2
e2m2$AgeClass[e2m2$Age >= 5 & e2m2$Age < 7.5] <- 3
e2m2$AgeClass[e2m2$Age >= 7.5 & e2m2$Age < 9] <- 4
e2m2$AgeClass[e2m2$Age >= 9 & e2m2$Age <12] <- 5
e2m2$AgeClass[e2m2$Age >= 12] <- 6

e2m2$AgeClass <- as.factor(e2m2$AgeClass)

## Now Calculate Age Class prevalence
age_prev <- group_by(e2m2,AgeClass)
stat_age <- summarise(age_prev,
                      pos=length(AgeClass[Prev=="1"]),
                      n=n(),
                      prev=pos/n)


## Plot it now
ggplot(stat_age,aes(AgeClass,prev)) +
  geom_bar(stat="identity") +
  scale_x_discrete(name="Age Class", breaks=c(1,2,3,4,5,6), labels=c("Juv1","juv2","juv2","sadt","adt1","adt2"))


## Alway keep in mind that this tutorial is a way like other to handle data. You should try playing with data
## i R. It is the only way you can master it.

##############       Thanks A lot !!!!  ##################