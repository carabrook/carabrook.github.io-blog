## Tutorial: Introduction to Model Fitting
## E2M2: Ecological and Epidemiological Modeling in Madagascar
## November 27-December 1, 2016

## Adapted from:
## Ferrari et al. 2005, Mathematical Biosciences
## Bjornstad 2016: Models and Data

## Cara Brook, 2016

## This tutorial introduces you to the concept of model fitting, here using
## maximum likelihood techniques to fit a discrete-time SIR model to a time series
## of measles case counts from Niamey, Niger

## By the end of this tutorial, you should be able to:
##
##  * Make a simple SIR model in discrete time.
##  * Visualize data from a time series of Infected and Susceptible case counts
##  * Fit a simple SIR model (i.e. estimate the transmission parameter) with 
##    maximum likelihood techniques.

rm(list=ls())
######################################################################
## Part One: Build your model to recreate your data

## First, load your data
dat <- read.csv("niamey_measles.csv", header=T)

## Always start by looking at your dataset
head(dat)

## Then, plot your data and decide on the state variables
## in your system. It looks like we have cases ("infecteds")
## over time. These cases are grouped in two-week intervals 
##(the generation time for measles) across one year.

par(cex=1.8)
plot(dat$week, dat$cases, type="b", ylab="measles cases", xlab="week of year")

## Now build a model to recover these data, given the appropriate
## processes. Our basic system of equations is as follows:

## S[t+1] = S[t] - beta*S[t]*I[t]/N
## I[t+1] = I[t] + beta*S[t]*I[t]/N - gamma*I[t]

## Where beta is the transmission coefficient and gamma is the 
## recovery rate (can also be represented as 1/duration of infection).

## Note that we do not need to keep track of the Recovered population
## because if S + I + R = 1, then we can always infer it from S and I.

## In a handy mathematical trick, if we set the timestep of the model
## equal to the generation time of the pathogen (here, 1/gamma), then 
## we can reduce the system above to the following:

## S[t+1] = S[t] - beta*S[t]*I[t]/N
## I[t+1] = beta*S[t]*I[t]/N

## So now, we build a discrete-time deterministic model that
## predicts I[t+1] from the interactions of S[t], beta, and I[t+1].
## Our data are merely a time series of cases, meaning that we will
## need to guess S and beta. For S, we actually only need to guess
## S0, because we can think of S0 as a bathtub that is constantly 
## drained as susceptibles become infected. So, the vector S starts 
## with S0 and then gets drained every timestep by the new number of 
## cases for that timestep. Later, we will optimize the parameters
## S0 and beta. But, to start, we'll guess S0 = 2000 and beta = 2.5.

## Remind me: What are the units for beta again?

## Simuate data and plot it with your model.
det.SIR = function(par) { 
  S0 = par[1]
  beta = par[2]
  time = seq(2,52,2)
  I <- rep(NA, length(time))
  S <- rep(NA, length(time))
  
  I[1] <- 1
  S[1] <- S0
  
  N = S[1] + I[1] 
  
  for (t in 1:(length(time)-1)){
    S[t+1] = S[t] - (beta * S[t]/N) * I[t]
    I[t+1] = (beta * S[t]/N) * I[t]
  }
  
  out = data.frame(S = S, I = I)
  return(out)
}
simA = det.SIR(par = c(2000, 2.5))

par(cex=1.8)
plot(dat$week, dat$cases, type="b", ylab="measles cases", xlab="week of year", ylim=c(0,600))
lines(dat$week[1:length(simA$I)], simA$I, col = "red")

## Model does a pretty good job, but but it overshoots our data by
## quite a bit. What does this suggest about our guess for beta?

## Would another beta possibly work better?

######################################################################
## Part Two: How likely are our data, given this model?

## We can write a likelihood function to ask this question: Assuming our model
## (with its stated parameters) is the truth, then how likely are we
## to recover our data?

## We do that here:
likelihood = function(par, I) { 
  n = length(I) 
  S0=par[1]
  beta=par[2]
  S = floor(S0 - cumsum(I[-n])) 
  p = 1 - exp(-beta * (I[-n])/S0) 
  L = -sum(dbinom(I[-1], S, p, log = TRUE)) # if you are a susceptible at timepoint t, then you have p probability of becoming infected. Given your model of S and p, how likely is it that we achieve the Is witnessed in the data (not in your model)
  return(L)
}

## We can ask how likely are our guessed parameters, above:
likelihood(par=c(2000,2.3), I = dat$cases)

## Returns value: 459.6033
## But we don't have a context for what this means. Likelihood values are only
## meaningful when compared against one another.

## Now, let's 'profile' over a range of possible values for beta
## and, at each beta, ask the question, how likely are we to get 
## our data, given that the model with this particular beta is truth:
beta_guess = seq(0, 10, by = 0.1)
ll = rep(NA, length = 101) 
for (i in 1:101) { 
  ll[i] = likelihood(par = c(2000, beta_guess[i]), I = dat$cases)
} 

## Then, we plot the negative log-likelihood versus each guess of beta
plot(ll ~ beta_guess, ylab = "neg log-lik", xlab = "beta")

## And we take the minimum and call it fact
beta_guess[which.min(ll)] #2.3
## We can simulate again with this new value of beta
simB = det.SIR(par = c(2000, 2.3))

## Let's see how this new beta estimate compares with our original guess:
par(cex=1.8)
plot(dat$week, dat$cases, type="b", ylab="measles cases", xlab="week of year", ylim=c(0,600))
lines(dat$week[1:length(simB$I)], simA$I, col = "red")
lines(dat$week[1:length(simB$I)], simB$I, col = "blue")
## It fits even better!

######################################################################
## Part Three: Optimize the parameters to produce the best model to fit the data

## But, remember, that we also guessed the initial susceptible population (S0), so the optimal
## beta might change if we started with a bigger population.
## Ideally, we would use R tools to simulataneously estimate the most likely S0 and beta
## to fit our data. optim() is one of the tools that can do this

out <- optim(par = c(2000, 2.5), likelihood, method = "Nelder-Mead", I = dat$cases)

## out$par returns the estimated optimal parameters to make
## your model fit your data: S0 = 2152, and beta = 2.09
## out$val gives the negative log-likelihood for the data, given the model with these parameters

## Try running your model with these values instead:
simC = det.SIR(par = c(2152, 2.09))

par(cex=1.8)
plot(dat$week, dat$cases, type="b", ylab="measles cases", xlab="week of year", ylim=c(0,600))
lines(dat$week[1:length(simA$I)], simA$I, col = "red")
lines(dat$week[1:length(simB$I)], simB$I, col = "blue")
lines(dat$week[1:length(simC$I)], simC$I, col = "green")
## Even better!

## Why does it still not match perfectly?

######################################################################
## Part Four: Redesign your model if need be.

## We can encompass the data in a stochastic model too
#using these estimated parameters at t=0
stoch.SIR = function(par) { 
  beta <- par[2]
  S0 <- par[1]
  I = 1 
  S = S0 
  i = 1
  
  while (!any(I == 0)) {
    i = i + 1 
    I[i] = rbinom(1, size = S[i - 1], prob = 1 - exp(-beta * I[i - 1]/S0))
    S[i] = S[i - 1] - I[i]
  }
  out = data.frame(S = S, I = I)
  return(out)
}
plot(dat$week, dat$cases, type="n", ylab="measles cases", xlab="week of year", ylim=c(0,600))
for (i in 1:100) { 
  stoch = stoch.SIR(par=c(2000, 2.3)) 
  lines(dat$week[1:length(stoch$I)], stoch$I, col = "cornflowerblue")
} 
points(dat$week, dat$cases, type = "b", lwd=2)

######################################################################
## Part Five: Just for Fun

## Now let's calculate the effective reproduction number throughout the epidemic.
## Remember that Reff[t] = R0 * S[t]/N
## Because we set the timestep of the model equal to the generation time of measles, 
## beta = R0 in our system.

## An epidemic will increase when Reff > 1 and decrease when Reff < 1

## So, if we use our new estimates for beta and S0, and our case counts of infecteds from the data:
beta <- 2.09
S0 <- 2152
S <- floor(S0 - cumsum(dat$cases))
N <- S0

R0 <- beta
Reff <- R0 * S/N

## We can plot R_e through time as well. Where should the epidemic start to decline?
plot(dat$week, Reff, type = "b",ylim=c(0,2), xlab="week of year")
abline(h=1, lty=2, col="red")


######################################################################
## Part Five: Just for Fun

## We might also like to look at the force of infection (FOI). The FOI
## helps us understand the trajectory of an epidemic from the perspective of
## infection risk to susceptible individuals. Here, FOI[t] = beta * I[t]/N. 

FOI <- beta * dat$cases/N

## We can plot this over time, as well. Because we only "count" the 
## number infected at the beginning of each timestep, FOI should be constant 
## across the duration of each time step, then change based on the new 
## proportion in the next timestep (hence the "stairs"):
plot(dat$week, FOI, type = "s", col="red", ylim=c(0,1), xlab = "week of year")



