# get working directory
getwd()
# set working directory to Fieldworkdata_reports on dropbox
setwd("~/Dropbox/E2M2/network")
######################### to build a network we will need to have a matrix, you can either import an edge list or a square dataframe
####edge list is a three column dataframe with node 1 node 2 and the link
####either way you will need to transform it into a Matrix

#######################################################################################################
########################################
# Public health officials are concerned about an outbreak of TB in a community near the Valbio
# they want to evaluate the risks of disease spreading in a small community
# and have collected interactions data among a group of 51 scientists from 6 institutions living in the 
# Centre Valbio
# import square data frame and put into matrix format
FULL<-read.csv("overallnetwork.csv", header=F)  
summary(FULL)
rownames(FULL)<-FULL[,1]
FULL<-FULL[,-1]
colnames(FULL)<-FULL[1,]
FULL<-FULL[-1,]
FULL<-apply(FULL,c(1,2), as.numeric)
FULL<-as.matrix(FULL)

#import nodeinfo object
nodeinfo<-read.csv("~/Dropbox/E2M2/network/nodeinfo.csv",header = T)
summary(nodeinfo)
str(nodeinfo)
nodeinfo$Group<-as.factor(nodeinfo$Group)
summary(nodeinfo$Group)

######################################################################
##############PLOT THE NETWORK

#loading library igraph
library(igraph)

net=graph.adjacency(FULL,mode="undirected",diag=FALSE,weighted=TRUE)
plot(net)

#####setting up vertices (nodes) colors, shape and size for group, sex and degree respectively

#match the name of vertices (Animal ID) to the species indicated in nodeinfo
V(net)$group=as.character(nodeinfo$Group[match(V(net)$name,nodeinfo$ID)])
V(net)$color=V(net)$group
plot(net)
V(net)$Sex=as.character(nodeinfo$Sex[match(V(net)$name,nodeinfo$ID)])
V(net)$shape=V(net)$Sex #assign the "Sex" attribute as the vertex shape
V(net)$shape=gsub("F","circle",V(net)$shape) #females will be circle
V(net)$shape=gsub("M","square",V(net)$shape) #males will be square

#degree and betweenness
deg<-degree(net)
nodeinfo$deg<-deg
bet<-betweenness(net)
nodeinfo$bet<-bet
#############plotting the network per se
plot(net, 
     vertex.size=10, 
     vertex.label=NA,
     edge.lty=1,edge.width=1,
     margin=c(-0.1,-0.1,0,0))

legend(x=0, y=-0.9, c("MISA", "IPM", "Biologie Animale", "Biologie vegetale","Faculte de medecine", "Instructors"), 
       pch=1, col=c(1:6),
       pt.cex=1.5, cex=.8, bty="n", ncol=1,y.intersp = 1)
legend(x=-1, y=-0.9, c("Male","Female"), 
       pch=c(1,0), pt.cex=1.5, cex=.8, bty="n", ncol=1,y.intersp = 1.2)

###############-----network level calculations
######## what is the average number of steps between any two pairs of individuals?
######## what is the proportion of realized links /possible links
mean_distance(net, directed=FALSE)
edge_density(net, loops=FALSE)

########transitivity measures the probability that the adjacent vertices of a focal vertex are connected aka clustering coefficient
transitivity(net) #are my friends also friend with each other?

#We are done with descriptions of the network and now we can answer the questions of our beloved public health officials
#### Dr Antso: Is there a group of individuals that have significantly more (or less) connections than members of other group?
#### ie. are members of certain group more likely to be superspreaders than others?

####degree is a count so is modelled using a glm either a poisson or a negative binomial model
#following Andres direction on day 1 suggest that degree best fits a negative binomial distribution
#We will first run a full model with all two explanatory variables (Group and Sex) 
require(foreign)
require(ggplot2)
require(MASS)
m1<-glm.nb(deg~Group+Sex+TBend, data = nodeinfo)
summary(m1)

#We see the regression coefficients for each of the variables, along with standard errors, z-scores, and p-values. 
#The variable sexM has a coefficient of 0.2, which is statistically significant. 
#This means that for males, the expected *log-count* of the number degrees increases by 0.2.
#The expected difference in log count between group 2 and the reference group (Group=1) is 0.86 higher.

#To determine if "Group" itself, overall, is statistically significant, we can compare a model with and without prog.
#The reason it is important to fit separate models, is that unless we do, the overdispersion parameter is held constant
m2<-update(m1,.~.-Group)
anova(m1, m2)
#The five degree-of-freedom chi-square test 
#indicates that Group is a statistically significant predictor of degree.

####... we can do similar models (although linear) to model betweenness

#################################################Dyadic, pairwise relationships among individuals
    ####Are infected individuals of the same group, TB status or sex more likely to interact with each other, than predicted by chance?

#######################MULTIPLE REGRESSION QUADRATIC ASSIGNMENT PROCEDURES-model
library(asnipe)
#multiple regression quadratic assignement procedure
#Calculate the regression coefficient for each input matrix. 
#This method randomises the residuals from the regression on each independent variable
#(fixed effect) in order to calculate the P-value. 
#This is the same as testing whether y(interaction) is related to
#x1 (sex similarity) while controlling for x2 (group belonging) and vice versa.
#Load the overall network create a Group or sex similarity matrix define group memberships (or read from file)
#####
sx<-data.frame(nodeinfo$ID,nodeinfo$Sex)
gbs<-get_group_by_individual(sx,data_format = "individuals")
net_sx<-get_network(gbs,data_format = "GBI")

tb<-data.frame(nodeinfo$ID,nodeinfo$TBend)
gbtb<-get_group_by_individual(tb,data_format = "individuals")
net_tb<-get_network(gbtb,data_format = "GBI")

sg<-data.frame(nodeinfo$ID,nodeinfo$Group)
gbg<-get_group_by_individual(sg,data_format = "individuals")
net_g<-get_network(gbg,data_format = "GBI")

#mrqap to explain similarity matrix based on distance matrix, similarity in species and sex

m.all<-mrqap.dsp(FULL~net_sx+net_g+net_tb,intercept=TRUE,directed="undirected",diagonal=F,test.statistic="beta",randomisations=1000)
m.all
############### SIR simulations in igraph
#crea
si<-sir(net, 1,1 , no.sim = 1000)
plot(si,median=F, color="grey", quantiles=F)
plot(si,comp="NR",add=T)