#install unmarked if not installed
install.packages("unmarked")
#load library
library(unmarked)

#set here the directory where your data files are located and import data
setwd("~/Dropbox/E2M2/occupancy")

##############---------------------------------------------------
#Our goal was to estimate the prevalence of antibodies (seroprevalence) against toxoplasma gondii a protozoan parasite spread by cats
#that can affect wild carnivores and cause fatal encephalomyelitis in fosa of Madagascar.
#however the ELISA test developped for cats was not validated in wild animals and the sensitivity and specificity
#of the test are unknown.
#the second objective of this study was to evaluate the influence of sex and species on the probability of being infected
#or the probability of showing up positive when infected.
#We collected blood/serum samples from wild carnivores belonging to two species 
#and tested each one three times
##############################################################################################
data<-read.csv("toxo.csv")
View(data)
summary(data)

#prevalence when testing once 
table(data$y.1)
prop.table(table(data$y.1))

######format dataframe to unmarkedframe
#detection data rows are sites columns are detection replicates
y<-data[,2:4] #here we indicate that column 2 to 4 corresponds to detection history

#site level (individual) covariates
toxo.site<-data[,5:7]


#put everything together in unmarked data frame
#note that covariate can come from separate files
toxo <- unmarkedFrameOccu(y = y, siteCovs = toxo.site)
#summary of unmarked data frame
summary(toxo)
#################################
#CREATING MODELS
#simple occupancy model no covariates
fm1<-occu(~1 ~1,toxo)
fm1


# Estimate for occupancy and detection are on logit scale and need transformation
#back transformations
backTransform(fm1,'det')
backTransform(fm1,"state")
#probability of detection given taxon is present, is only 55%
#probability that taxon is present is 89%

#create some more occupancy models
#constant detection, constant occupancy
fm1<-occu(~1 ~1,toxo)
#constant detection, occupancy predicted by species 
fm2<-occu(~1 ~species,toxo)
#constant detection, occupancy predicted by sex 
fm3<-occu(~1 ~sex,toxo)
#constant detection, occupancy predicted by sex+species
fm4<-occu(~1 ~sex+species,toxo)
#detection varies between species, occupancy constant 
fm5<-occu(~species ~1,toxo)
#detection varies between species, occupancy predicted by species
fm6<-occu(~species ~species,toxo)

########which of these models are the best
#built-in model selection
#labeled list of models
fmlist<-fitList("null"=fm1,"psi_sp"=fm2,"psi_sx"=fm3,"psi_sx+sp"=fm4, "p_sp"=fm5, "psi_p_sp"=fm6)
#model selection -- ranked list of models and AIC
modSel(fmlist)




####### Goodness of fit test (Chi square) to assess whether our model fits with the data
####ie. is our model valid?
###

chisq<-function(fm) {
  observed<-getY(fm@data)
  expected<-fitted(fm)
  sum((observed-expected)^2/expected)
}
(pb<-parboot(fm2,statistic=chisq,nsim=200, parallel=FALSE))

######predict to backtransform estimates when there are covariates in the model
####e.g. want to transform the occupancy estimates obtained from the model fm3
backTransform(fm1,'state')
nd <- data.frame(sex=c("M", "F"))
predict(fm3, type='state',newdata=nd)


###############################################################- BEYOND SINGLE SPECIES SINGLE SEASON

###################### Abundance induced heterogeneity

##############################################Royle count model
######format dataframe to unmarkedframe
#detection data rows are sites columns are detection replicates
n<-nrow(data) #optional
counts<-data[,8:10]
View(data)
#load site level (individual) covariates
toxo_count.site<-data[,5:7]
toxo_count <- unmarkedFramePCount(y = counts, siteCovs = toxo_count.site)
summary(toxo_count)

#fit models assuming abundance has a negative binomial distribution
#fit null model = detection probability and abundance are constant

pc1<-pcount(~1~1,toxo_count,mixture="NB")
pc1

pc2<-pcount(~1~1,toxo_count,mixture="ZIP")
pc2

#convert estimates from link scale to original scale 
#"backTransform" when no covariates
backTransform(pc1,"state")
backTransform(pc1,"det")

# Another way of doing the same thing
exp(coef(pc1, type="state"))		# Abundance
plogis(coef(pc1, type="det"))		# Det. prob

#########################################################################
###################----------Dynamic occupancy models
########################
#####
#model probability of occupancy, detection, extinction and colonization 
#using colext function in unmarked

################made up data survey 267 sites
#each site is surveyed 3x every year during 9 years (2010-2018)
#noted presence and absence each survey
#want to know if probability of occupancy varies according to forest cover
#want to know the probability of extinction and colonization of the taxon each year
data<-read.csv("varecia.csv")
View(data)
yvar <- as.matrix(data[,5:31])
years <- as.character(2010:2018)
years <- matrix(years, nrow(data), 9, byrow=TRUE) #create a matrix to indicate the year(period) each site was survey  yearly 
umf <- unmarkedMultFrame(y=yvar,
                         siteCovs=data[,2:3], 
                         yearlySiteCovs=list(years=years),
                         numPrimary=9)
summary(umf)


#### null dynamic occupancy model
fm0 <- colext(psiformula=~1,
              gammaformula= ~1,
              epsilonformula= ~1, 
              pformula= ~1, umf)
fm0 #null model where all estimates are constant

#fit a couple more dynamic occupancy model with colonization extinction and detection that are dependant on age 
fm1 <- colext(psiformula = ~1,   # occupancy is constant
             gammaformula = ~ years-1,    # Colonization
             epsilonformula = ~ years-1,  # Extinction
             pformula = ~ years-1,        # Detection
             data = umf)

fm2 <- colext(psiformula = ~forest,   # Occupancy is forest dependent
              gammaformula = ~ years-1,    # Colonization
              epsilonformula = ~ years-1,  # Extinction
              pformula = ~ years-1,        # Detection
              data = umf)

models<-fitList(fm0,fm1,fm2)
modSel(models)
####fm2 with forest as factor of occupancy is the best model

######predict and plot


nd <- data.frame(forest=seq(0, 100, length=50))
E.psi <- predict(fm2, type="psi", newdata=nd, appendData=TRUE)
with(E.psi, {
  plot(forest, Predicted, ylim=c(0,1), type="l",
       xlab="Percent cover of forest",
       ylab=expression(hat(psi)), cex.lab=0.8, cex.axis=0.8)
  lines(forest, Predicted+1.96*SE, col=4)
  lines(forest, Predicted-1.96*SE, col=4)
})
nd <- data.frame(years=c('2010','2011','2012','2013','2014','2015','2016','2017')) 
E.ext <- predict(fm2, type='ext', newdata=nd)
E.col <- predict(fm2, type='col', newdata=nd)
nd <- data.frame(years=c('2010','2011','2012','2013','2014','2015','2016','2017','2018'))
E.det <- predict(fm2, type='det', newdata=nd)



with(E.ext, {   # Plot for extinction probability
  plot(1:8, Predicted, pch=1, xaxt='n', xlab='Years',ylab='extinction probability', ylim=c(0,1), col=4)
  axis(1, at=1:8, labels=nd$years[1:8])
  arrows(1:8, lower, 1:8, upper, code=3, angle=90, length=0.03, col=4)
})


with(E.col, {   # Plot for detection probability
  plot(1:8, Predicted, pch=1, xaxt='n', xlab='Years',ylab='colonization probability', ylim=c(0,1), col=4)
  axis(1, at=1:8, labels=nd$years[1:8])
  arrows(1:8, lower, 1:8, upper, code=3, angle=90, length=0.03, col=4)
})


with(E.det, {   # Plot for detection probability
  plot(1:9, Predicted, pch=1, xaxt='n', xlab='Years',ylab='detection probability', ylim=c(0,1), col=4)
  axis(1, at=1:9, labels=nd$years[1:9])
  arrows(1:9, lower, 1:9, upper, code=3, angle=90, length=0.03, col=4)
})

