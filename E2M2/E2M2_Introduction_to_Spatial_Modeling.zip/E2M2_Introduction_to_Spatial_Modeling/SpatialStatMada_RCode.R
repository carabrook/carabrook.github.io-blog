setwd('~/Dropbox/Teaching/SpatialStatsMada/')

### loading in a shp file
library(maptools)
library(rgdal)
library(rgeos)

mdg_admin2_shp<-readShapePoly('MDG_Shp/MDG_adm2.shp', proj4string = CRS('+proj=longlat'))
mdg_admin2_shp<-gSimplify(mdg_admin2_shp, tol = 0.01)

par(mfrow=c(1,3))
plot(mdg_admin2_shp)

## loading in a raster file
library(raster)
library(rgdal)
library(colorRamps)

mdg_birth<-raster('MDG_Births/MDG_births_pp_v2_2015.tif')

par(mfrow=c(1,3))
image(mdg_birth, col = blue2red(100))
image(log(mdg_birth+1), col = blue2red(10))

## let's combine the raster and shp files

par(mfrow=c(1,3))
image(mdg_birth, zlim = c(0,3000))
plot(mdg_admin2_shp, add = TRUE)

## now let's read in some point process data and make a plot

deaths_points_file<-read.csv('Snow_deaths.csv', header = TRUE)
pumps_points_file<-read.csv('Snow_pumps.csv', header = TRUE)
street_points_file<-read.csv('Snow_streets.csv', header = TRUE)


par(mfrow=c(1,1))
plot(NA, NA, xlim = range(street_points_file$x), ylim = range(street_points_file$y), xlab = '', ylab = '', bty = 'n', xaxt = 'n', yaxt = 'n')

for(ii in 1:max(street_points_file$street)){
  sub_dat<-street_points_file[which(street_points_file$street == ii),]
  lines(c(sub_dat$x[1], sub_dat$x[2]), c(sub_dat$y[1], sub_dat$y[2]))
}

points(deaths_points_file$x, deaths_points_file$y, col = 'red')

points(pumps_points_file$x, pumps_points_file$y, col = 'blue', pch = 16)

legend('bottomleft', legend = c('pumps', 'deaths'), col = c('blue', 'red'), pch = 16)

## and here is an additional function to make a plot of the data

plot_streets<-function(){
  plot(NA, NA, xlim = range(street_points_file$x), ylim = range(street_points_file$y), xlab = '', ylab = '', bty = 'n', xaxt = 'n', yaxt = 'n', add = TRUE)
  
  for(ii in 1:max(street_points_file$street)){
    sub_dat<-street_points_file[which(street_points_file$street == ii),]
    lines(c(sub_dat$x[1], sub_dat$x[2]), c(sub_dat$y[1], sub_dat$y[2]))
  }
}

plot_base_snow_plot<-function(){
  par(mfrow=c(1,1))
  plot(NA, NA, xlim = range(street_points_file$x), ylim = range(street_points_file$y), xlab = '', ylab = '', bty = 'n', xaxt = 'n', yaxt = 'n')
  
  for(ii in 1:max(street_points_file$street)){
    sub_dat<-street_points_file[which(street_points_file$street == ii),]
    lines(c(sub_dat$x[1], sub_dat$x[2]), c(sub_dat$y[1], sub_dat$y[2]))
  }
  
  points(deaths_points_file$x, deaths_points_file$y, col = 'red')
  
  points(pumps_points_file$x, pumps_points_file$y, col = 'blue', pch = 16)
  
  legend('bottomleft', legend = c('pumps', 'deaths'), col = c('blue', 'red'), pch = 16)
}

mean_x = mean(deaths_points_file$x)
mean_y = mean(deaths_points_file$y)

sd = sqrt(sum((deaths_points_file$x - mean_x)^2 + (deaths_points_file$y - mean_y)^2)/length(deaths_points_file$x))

plot_base_snow_plot()
bearing = 1:360*pi/180
cx = mean_x + sd * cos(bearing)
cy = mean_y + sd * sin(bearing)
circle <- cbind(cx, cy)
lines(circle, col = 'green', lwd = 2)

numb_pumps<-nrow(pumps_points_file)
mean_distance<-rep(NA, numb_pumps)
for(jj in 1:numb_pumps){
  single_pump_coord<-pumps_points_file[jj,]
  euc_dist_from_single_pump<-sqrt((deaths_points_file$x - single_pump_coord$x)^2 + (deaths_points_file$y - single_pump_coord$y)^2)
  mean_distance[jj] = mean(euc_dist_from_single_pump)
}

## How does the mean distance from Broad Street pump compares to the other pumps? 

## * TO DO: Would you make the same inference if you compared the distributions of the distances (not just the means)? How would you compare these?

## Look at vaccination coverage

library(mgcv)
dhs<-read.csv('Madagascar2008-2009.csv', header = TRUE)
good<-which(dhs$long != 0 & dhs$lat != 0, arr.ind = TRUE)
fit<-gam(measles.y~s(age.in.months)+s(long,lat), family = 'binomial', data = dhs[good,])

summary(fit)

plot(fit, select = 1, trans = function(x)exp(x)/(1+exp(x)), xlim = c(0,60), ylim = c(0,1.5), xlab = 'Age in months', ylab = 'Proportion vaccinated')

library(maps) 
vis.gam(fit,view=c("long","lat"),plot.type="contour",too.far=0.1,type="response",color="cm",ylim=c(-30,-10),xlim=c(35,55), xlab="", ylab="", main="") 
points(dhs$long[good], dhs$lat[good], pch=19,cex=0.2)
map(add=TRUE)

## R is able to interface with google -- now let's try to use that to calculate some travel times between locations

library(googleway)
library(leaflet)
library(raster)

## Google directions API
key<-"AIzaSyCuhQ4K6pVY1jl62qXvAmhNTiw3GQDoSKk"

test_distance<- google_distance(origin = "Antananarivo Airport, Madagascar", destination = "Mahajanga, Madagascar", key = key, mode = "driving")

driving_distance<-test_distance$rows
print(driving_distance)

test_route<- google_directions(origin = "Antananarivo Airport, Madagascar", destination = "Mahajanga, Madagascar", key = key, mode = "driving")

# get encoded route
route <- test_route$routes$overview_polyline$points
test_route <- decode_pl(route)
head(test_route)

# plot result
map <- leaflet() %>%
  addTiles("http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png")

map %>% addPolylines(test_route$lon, test_route$lat)



